# Writer: Farah Nusrat
# Course No: NRS 568
# Midterm Project

# Project: Interpolation of Diarrhea disease for Spring season, 2014 in Bangladesh

# Objective:
#
# To create an interpolated layer of Diarrhea disease data all over Bangladesh
# using 65 stations data to get an idea about disease condition in any intermediate
# locations of the stations only by knowing latitude and longitude.

# Workflow:
#
# I tried to create a seasonal kriging layer for 65 stations of Bangladesh.
# From the latitude-longitude first the stations locations are created as events along with total
# patients admitted in the whole Spring season (March, April, May) in whole Bangladesh. Then
# they are converted to shapefile and then the interpolation layer created by using "Kriging Method"
# and clipped using the Bangladesh Administrative area shapefile. Then the Pearson Correlation values are
# calculated, which is a measure of the linear correlation between two variables "Spring_T" and "RASTERVALU".
# It is mainly done for checking/validation of the processes used.In the end, all intermediate files are deleted.

# Import arcpy module and other necessary modules

import arcpy
from scipy.stats.stats import pearsonr
arcpy.CheckOutExtension("Spatial")

# Declare a workspace

arcpy.env.workspace = r"J:\paper\trial"
arcpy.env.overwriteOutput = True

# Define Local Variables

data = "diarrhea_data.csv"
events = "event_xy"
output_folder = arcpy.env.workspace
hospitals = "hospitals.shp"
hospital_new = "hospital_nw.shp"
krig_layer = "krigging.tif"
Bangladesh = "BGD_adm1.shp"
BD_krig = "bd_krig.tif"
print ("variables assigned!")

# Set Geoprocessing environments

# Geoprocessing extent of the output will be same as the shapefile of Bangladesh
arcpy.env.snapRaster = ""
arcpy.env.extent = "88.0105667114258 20.7411117553712 92.6736602783204 26.6343994140626"

# Make XY Event Layer

# Input file is the csv file
# Output is event layer
layer = arcpy.MakeXYEventLayer_management(data, "lon", "lat", events)
print ("events created")

# Checking the coordinate system: correct or not

# We need to check the spatial reference for the events,
# so that when shapefile is created from these, will have same reference.
# The spatial reference for Bangladesh is GCS_WGS 1984.

desc = arcpy.Describe(layer)
print desc.spatialReference.name

# Converting events to Shapefile

# input = event layer
# output = point shape file of all hospital locations in Bangladesh those keep track of diarrhea disease data
Shapefile = arcpy.FeatureClassToFeatureClass_conversion(events, output_folder, "hospitals")
print ("shapefile done!!!")

# Kriging analysis

# input file = shapefile of hospital locations
# field used for Kriging = Spring_T = Total diarrhea affected people in Spring (March, April, May) Season, 2014
# output = an interpolated layer named "krig_layer" which is in TIFF format
# Kriging Method = Ordinary
# Semivariogram model type = Spherical
# Lag size = 0.016333
# Output cell size = 0.0163332
# Search Radius Type = Variable
# No. of Points for Search Radius = 12
kriging = arcpy.gp.Kriging_sa(hospitals, "Spring_T", krig_layer, "Spherical 0.0163332", "0.016333", "VARIABLE 12")
print ("kriging complete!")

# Clipping process
# input = krig_layer = an interpolated layer
# shapefile used for clipping = Bangladesh
# extent of the clipping area = "88.0105667114258 20.7411117553712 92.6736602783204 26.6343994140626"
# output = BD_krig

BD_Kriging = arcpy.Clip_management(krig_layer, "88.0105667114258 20.7411117553712 92.6736602783204 26.6343994140626",
                                   BD_krig, Bangladesh, "", "ClippingGeometry", "NO_MAINTAIN_EXTENT")
print ("clipping done")

# Process: Extract Values to Points

# A process to extract values from the interpolated layer and stored in a new column of a new shapefile.
# input = hospital locations
# output = hospital_new
# It will add a new column named "RASTERVALU" of the hospital shapefile by taking values from interpolated layer
# "BD_krig" for each station locations and renamed as "hospital_new"

arcpy.gp.ExtractValuesToPoints_sa(hospitals, BD_krig, hospital_new, "NONE", "VALUE_ONLY")

# Validation using Pearson Correlation Method

# A process to check or validate the interpolated layer in previous step.

arr = arcpy.da.FeatureClassToNumPyArray(hospital_new, ["Spring_T", "RASTERVALU"])
print "Pearson Correlation of Interpolated Layer = " + str(pearsonr(arr["Spring_T"], arr["RASTERVALU"]))
print "Pearson Correlation Calculation Done!!"

# deleting intermediate files (kriging layer)

arcpy.Delete_management(kriging)
print ("Congratulations: All intermediate files are deleted!!!")
print("PROJECT COMPLETED SUCCESSFULLY!!!")




