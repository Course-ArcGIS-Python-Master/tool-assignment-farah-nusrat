# I tried to create a seasonal kriging layer for 64 stations of Bangladesh.
# From the latitude-longitude first the stations locations' are created as events along with total
# patients admitted in the whole Spring season (March, April, May) in whole Bangladesh. Then
# they are converted to shapefile and then the interpolation layer created and clipped
# using the Bangladesh administrative area shapefile. In the end, all intermediate files
# are deleted except the clipped kriging tiff file.

# Import arcpy module
import arcpy

arcpy.CheckOutExtension("Spatial")

# Declare a workspace
arcpy.env.workspace = r"J:\NRS 568\midterm_project\trial"

# Local variables
data = "diarrhea_data.csv"
events = "event_xy"
output_folder = arcpy.env.workspace
hospitals = "hospitals.shp"
krig_layer = "krigging.tif"
Bangladesh = "BGD_adm1.shp"
BD_krig = "bd_krig.tif"
print ("variables assigned!")

# Make XY Event Layer

layer = arcpy.MakeXYEventLayer_management(data, "lon", "lat", events)
print ("events created")

# We need to check the spatial reference for the events,
# so that when shapefile is created from these, will have same reference.
# The spatial reference for Bangladesh is GCS_WGS 1984.

# Checking the coordinate system: correct or not
desc = arcpy.Describe(layer)
print desc.spatialReference.name

# Converting events to Shapefile
Shapefile = arcpy.FeatureClassToFeatureClass_conversion(events, output_folder, "hospitals")
print ("shapefile done!!!")

# Kriging analysis
# Here, spring_tot is the variable. It is the summation of all patients that
# are admitted to hospital due to diarrhea during spring (March, April, May) in 2011 in whole Bangladesh.

kriging = arcpy.gp.Kriging_sa(hospitals, "spring_tot", krig_layer, "Spherical 0.016320", "0.01632", "VARIABLE 12")
print ("kriging complete!")

# Clipping process
BD_Kriging = arcpy.Clip_management(krig_layer, "88.0105667114258 20.7411117553712 92.6736602783204 26.6343994140626",
                                   BD_krig, Bangladesh, "", "ClippingGeometry", "NO_MAINTAIN_EXTENT")
print ("clipping done")

# deleting intermediate files (shapefile and kriging layer)
arcpy.Delete_management(Shapefile)
arcpy.Delete_management(kriging)
print ("Congratulations: All intermediate files are deleted!!!")